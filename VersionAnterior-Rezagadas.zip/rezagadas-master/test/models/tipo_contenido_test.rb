require 'test_helper'

class TipoContenidoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
