require 'test_helper'

class EntradaBlogTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
