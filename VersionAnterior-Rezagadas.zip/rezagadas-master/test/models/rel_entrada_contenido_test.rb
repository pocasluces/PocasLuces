require 'test_helper'

class RelEntradaContenidoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
