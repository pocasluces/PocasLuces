require 'test_helper'

class ActualizacionTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
