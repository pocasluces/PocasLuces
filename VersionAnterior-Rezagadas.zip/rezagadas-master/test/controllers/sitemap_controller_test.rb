require 'test_helper'

class SitemapControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
