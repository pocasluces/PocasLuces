#!/usr/bin/env ruby

require 'pg' unless defined?( PG )


module PG::Constants

	# Most of these are defined in the extension.

end # module PG::Constants

