class TipoContenido < ActiveRecord::Base

	belongs_to :entrada_blogs


end
