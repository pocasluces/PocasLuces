class ApplicationMailer < ActionMailer::Base
  default from: "noresponder@pocasluces.com"
  layout 'mailer'
end
