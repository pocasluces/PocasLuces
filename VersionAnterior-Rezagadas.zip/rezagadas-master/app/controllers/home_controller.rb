class HomeController < ApplicationController

layout 'application'


  def index
  end

end
